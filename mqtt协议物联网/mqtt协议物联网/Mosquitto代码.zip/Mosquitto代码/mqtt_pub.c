﻿#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <mosquitto.h>
#include "cJSON.h"


void mqtt_log_callback(struct mosquitto *mqtt, void *ubuf, int level, const char *str)
{
	printf("[log] level=%d str=%s ubuf=%s\n", level, str, (char *)ubuf);
}

void mqtt_connect_callback(struct mosquitto *mqtt, void *ubuf, int result)
{
	int i;
	printf("[connect] level=%d\n", result);

	if(!result){
		/* Subscribe to broker information topics on successful connect. */
		mosquitto_subscribe(mqtt, NULL, "topeet", 2);
	}else{
		fprintf(stderr, "Connect failed\n");
	}
	
}

void mqtt_message_callback(struct mosquitto *mqtt, void *ubuf, const struct mosquitto_message *message)
{
	if(message->payloadlen){
		printf("%s %s\n", message->topic, (char *)message->payload);
	}else{
		printf("%s (null)\n", message->topic);
	}
	fflush(stdout);
}

void mqtt_disconnect_callback(struct mosquitto *mosq, void *obj, int result)
{
	printf("mqtt disconnect\n");
}

void mqtt_publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
      printf("mqtt_publish_callback\n");
}


int main(int argc, char *argv[])
{
	int ret;
	int session = true;	
	char buf[1024];
	char name[] = "topeet";
	
	
	struct mosquitto *mosquitto_pub = NULL;

	mosquitto_lib_init();   

	mosquitto_pub = mosquitto_new(name, session, NULL);
	if(!mosquitto_pub){
		printf("mqtt new client error\n");
		return -1;
	}

    mosquitto_connect_callback_set(mosquitto_pub, 		mqtt_connect_callback);
    mosquitto_message_callback_set(mosquitto_pub, 		mqtt_message_callback);
	mosquitto_disconnect_callback_set(mosquitto_pub, 	mqtt_disconnect_callback);
    mosquitto_publish_callback_set(mosquitto_pub, 		mqtt_publish_callback);


	ret = mosquitto_connect(mosquitto_pub, argv[1], 1883, 60);
	if(ret){
		printf("connect error\n");
		return ret;
	}
	printf("connect succeed\n");
	
	while(1)
	{
		cJSON *json;
		char *json_buf;
		memset(buf, 0, sizeof(buf));
		fgets(buf, sizeof(buf), stdin);

		json = cJSON_CreateObject();
		//封装。
		cJSON_AddNumberToObject(json, "led", buf[0] - '0');
		json_buf = cJSON_Print(json);
		
	
		if(strcmp(buf, "\n") == 0){
			printf("bye....\n");
			break;
		}
        
        mosquitto_publish(mosquitto_pub, NULL, "topeet", strlen(json_buf)+1, json_buf, 0, 0);
    }
	
	return 0;
}


