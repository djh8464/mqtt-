#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "cJSON.h"
//用cJSON要包含cJSON头文件
//写CJSON共四部。

int main(int argc, char **argv)
{

	cJSON *json;
	char *buf;
	char *led1;
	int  led2;

	//1.创建cJSON
	json = cJSON_CreateObject();

	//2.封装
	cJSON_AddStringToObject(json, "led1", "on");
	cJSON_AddNumberToObject(json, "led2", 1);
	/*封装成键值对。
	{
		“led1”：“on”
		“led2”：1
	}
	*/

	//将cJSON的键值对解析成字符串。（创建在堆，所以一定在后面释放。）
	buf = cJSON_Print(json);

	printf("%s\n", buf);



	//3.解析
	cJSON* cjson = cJSON_Parse(buf);
	if(cjson == NULL){
		printf("json pack into cjson error...\n");
	}else{
		
		int output;

		led1 = cJSON_GetObjectItem(cjson, "led1")->valuestring;
		led2 = cJSON_GetObjectItem(cjson, "led2")->valueint;


		printf("led1=%s\n", led1);
		printf("led2=%d\n", led2);

		
		cJSON_Delete(cjson);
	}

	



	//4.释放内存。
	free(buf);
	cJSON_Delete(json);

	
	return 0;
}
