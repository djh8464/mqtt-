#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <mosquitto.h>

#include "cJSON.h"
void mqtt_log_callback(struct mosquitto *mqtt, void *ubuf, int level, const char *str)
{
	printf("[log] level=%d str=%s ubuf=%s\n", level, str, (char *)ubuf);
}

void mqtt_connect_callback(struct mosquitto *mqtt, void *ubuf, int result)
{
	int i;
	printf("[connect] level=%d\n", result);

	if(!result){
		/* Subscribe to broker information topics on successful connect. */
		mosquitto_subscribe(mqtt, NULL, "NHS", 2);
	}else{
		fprintf(stderr, "Connect failed\n");
	}
	
}

void mqtt_message_callback(struct mosquitto *mqtt, void *ubuf, const struct mosquitto_message *message)
{
	printf("mqtt_message_callback..\n");
	if(message->payloadlen){
		printf("%s %s\n", message->topic, (char *)message->payload);
		cJSON* cjson = cJSON_Parse((char *)message->payload);	

		if(cjson ==NULL){
			printf("json pack into json error....\n");
		}else{
			if(cJSON_GetObjectItem(cjson, "beep")!=NULL){
				int val=cJSON_GetObjectItem(cjson, "beep")->valueint;	
				if(val==1){
						system(" ./buzzertest 1 1  "); 
				}else if(val==0){
						system(" ./buzzertest 0 1  "); 
				}
				printf("val=%d\n",val);
			}
			else if(cJSON_GetObjectItem(cjson, "led")!=NULL){
				int val=cJSON_GetObjectItem(cjson, "led")->valueint;	
				if(val==1){
						system(" ./leds 1 1  "); 
				}else if(val==0){
						system(" ./leds 0 1  "); 
				}
				printf("val=%d\n",val);
			}
			else if(cJSON_GetObjectItem(cjson, "switchBt")!=NULL){
				int val=cJSON_GetObjectItem(cjson, "switchBt")->valueint;	
				if(val==1){
						system(" ./relay 1  "); 
				}else if(val==0){
						system(" ./relay 0  "); 
				}
				printf("val=%d\n",val);
			}
			else if(cJSON_GetObjectItem(cjson, "curtainBt")!=NULL){
				int val=cJSON_GetObjectItem(cjson, "curtainBt")->valueint;	
				if(val==1){
						system(" ./step_motor_app R 4096 3000  "); 
				}else if(val==0){
						system(" ./step_motor_app L 4096 3000  "); 
				}
				printf("val=%d\n",val);
			}
		cJSON_Delete(cjson);
		}
	}
	else{
		printf("%s (null)\n", message->topic);
	}
	fflush(stdout);
}

void mqtt_disconnect_callback(struct mosquitto *mosq, void *obj, int result)
{
	printf("mqtt_disconnect\n");
}

void mqtt_publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
      printf("publish_callback\n");
}




int main(int argc, char *argv[])
{
	char buf[1024];
	bool session = true;
	char name[] = "mqtt";

	struct mosquitto *mosquitto_sub = NULL;

	mosquitto_lib_init();

	mosquitto_sub = mosquitto_new(name, session, NULL); 
    if(!mosquitto_sub){
        printf("create sub failed..\n");
        mosquitto_lib_cleanup();
        return 1;
    }

	 mosquitto_log_callback_set(mosquitto_sub, mqtt_log_callback);
    mosquitto_connect_callback_set(mosquitto_sub, mqtt_connect_callback);
    mosquitto_message_callback_set(mosquitto_sub, mqtt_message_callback);
	mosquitto_disconnect_callback_set(mosquitto_sub, mqtt_disconnect_callback);
    mosquitto_publish_callback_set(mosquitto_sub, mqtt_publish_callback);


	if(mosquitto_connect(mosquitto_sub, argv[1], 1883, 60)){
		fprintf(stderr, "connect failed\n");
		return 1;
	}
	printf("start recv...\n");

	mosquitto_loop_forever(mosquitto_sub, -1, 1);


	return 0;
}




